import sys
import os
from model.cemployees import Cemployees


def listado():
    res = obj.listar()
    print( res )


if __name__ == '__main__': 
    res = None
    obj = Cemployees()

    listado()
            
