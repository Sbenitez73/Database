from model.cmysql import *
from os import system 

class Cpayments( Cmysql ):
    def listar( self, iduser=None ):    
        cnn,crs = self.conectar()   
        sSQL = "SELECT * FROM payments"
        
        try:
            crs.execute( sSQL )
            results = crs.fetchall()
            
            print("ID\tCODIGO\t\t\t\tFECHA DE PAGO\t\t\tMONTO")
            
            for row in results:
                print( "%d\t%s\t\t\t%s\t\t%f" % ( row["customerNumber"], row["checkNumber"], row["paymentDate"], row["amount"] ))
                #print ("%d\t%s\t%s\t%s" % (employeeNumber, lastName, firstName, email ))
                
        except crs.InternalError() as error:
            code, message = error.args
            print("ERROR: ", code, message)
            
        finally:
            cnn.close()
            
            
    def consultar(self,iduser = None):
    	print ("********************************")
    	print ("      CONSULTAR PAYMENT")
    	print ("********************************")
    	cnn,crs = self.conectar()   
    	num = int(input("Ingrese el numero del customer: "))
    	sSQL = "SELECT * from payments WHERE customerNumber = %d"%num
    	
    	try:
    		crs.execute( sSQL )
    		results = crs.fetchall()
  
    		print("ID\tCODIGO\t\t\t\tFECHA DE PAGO\t\t\tMONTO")
    		
    		for row in results:
    			print( "%d\t%s\t\t\t%s\t\t%f" % ( row["customerNumber"], row["checkNumber"], row["paymentDate"], row["amount"] ))
    	
    	except crs.InternalError() as error:
    		code, message = error.args
    		print("ERROR: ", code, message)
    		
    	finally:
    		cnn.close()
		
    def modificar(self,iduser = None):
        system("clear")
        print ("********************************")
        print ("      MODIFICAR PAYMENT")
        print ("********************************")
        cnn,crs = self.conectar()
        num = int(input("Ingrese el numero del customer: "))
        check_n =  str(input("Ingrese el numero checkNumber: "))
        payment_d = str (input("Ingrese la nueva fecha separador por guion: "))
        amount_p = float(input("ingrese el nuevo monto separado por punto: "))
        sSQL = "UPDATE payments SET checkNumber = '%s', paymentDate = '%s', amount = '%f' WHERE customerNumber = %d"
        try:
            crs.execute( sSQL%(check_n,payment_d,amount_p,num))
            results = crs.fetchall()
            cnn.commit()
            system("clear")
            print("******************************************")
            print("LOS CAMBIOS SE HAN REALIZADO EXITOSAMENTE")
            print("******************************************")
            print("consulte por numero de customer para ver los cambios")
            input()

                

        except crs.InternalError() as error:
            code,message = error.args
            print("ERROR", code,message)

        finally:
            cnn.close()
 		
    def eliminar(self,iduser = None):
        system("clear")
        print ("********************************")
        print ("      ELIMINAR PAYMENT")
        print ("********************************")
        cnn,crs = self.conectar()
        num = int(input("Ingrese el numero del customer: "))
        sSQL = "DELETE FROM payments WHERE customerNumber = %d"%num

        try:
            crs.execute(sSQL)
            cnn.commit()

            
            print ("***************************************************")
            print ("LA FILA DEL CUSTOMER No %d SE ELIMINO EXITOSAMENTE"%num )
            print ("***************************************************")
            input()

        except crs.InternalError() as error:
                code, message = error.args
                print ("ERROR" .code. message)

        finally:
                cnn.close()

    def insertar(self,iduser = None):
        system("clear")
        print ("***************************************************")
        print ("             CREAR DATOS PAYMENTS                 " )
        print ("***************************************************")
        num = int(input("Ingrese el codigo para el customer: "))
        ck_n = str(input("ingrese el codigo de chequeo: "))
        date = str (input("Ingrese la fecha de compra separador por guion: "))
        amount_p = float(input("Ingrese el monto de la compra: "))
        cnn,crs = self.conectar()
        sSQL = "INSERT INTO payments VALUES (%d,'%s','%s',%f)"

        try:
            crs.execute(sSQL %(num,ck_n,date,amount_p))
            results = cnn.commit()

        except crs.InternalError() as error:
                code, message = error.args
                print("ERROR: ", code, message)

        finally:
                cnn.close()



