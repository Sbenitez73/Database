# -*- coding: utf-8 -*-

from os import system 
from model.cpayments import Cpayments

class Menu(object):
	def __init__(self):
		self.lista = Cpayments()

		
	def listar(self):
		self.lista.listar()
		input()
		
	def consultar_datos(self):
		self.lista.consultar()
		input()
	
	def modificar_datos(self):
		self.lista.modificar()

	def eliminar_datos(self):
		self.lista.eliminar()

	def insertar_datos(self):
		self.lista.insertar()
	
	def head_menu(self):
		system("clear")
		print ("***********************************")
		print ("***********************************")
		print ("******                      *******")
		print ("******        PRODUCTS      *******")
		print ("******     CLASSICMODELS    *******")
		print ("******        DATABASE      *******")
		print ("******                      *******")
		print ("***********************************")
		print ("***********************************")
		print ("***********************************")
		print ("               MENU                ")
		print ("***********************************")
		print ("***********************************")
		print ("1=Insertar datos a la tabla")
		print ("2=Consultar Tabla")
		print ("3=Modificar datos de la tabla ")
		print ("4=Borrar datos ")
		print ("5=Listar tabla ")
		print ("6=Salir")
		print ("***********************************")
		print ("***********************************")
		
		
	
		
	def menu_principal(self):
		while True:
			self.head_menu()
			try:
				opcion = int(input("Elige una opcion dentro del rango: "))
				print ("\n")
					
				if opcion ==1:
					
					self.insertar_datos()
								
				elif opcion ==2:	
					
					self.consultar_datos()
				
				elif opcion ==3:
					self.modificar_datos()
				
				elif opcion==4:
					self.eliminar_datos()
						
				elif opcion==5:
					self.listar()
						
				elif opcion ==6:
					break
		
		
			except ValueError:
				print ("La cantidad ingresada esta fuera de rango")
				input()
		
if __name__=='__main__':
	menu = Menu()
	menu.menu_principal()
		
